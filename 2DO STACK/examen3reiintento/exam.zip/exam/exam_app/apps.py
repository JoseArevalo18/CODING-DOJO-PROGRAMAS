from django.apps import AppConfig


class ExamAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'exam_app'
